#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <errno.h>

int main(int argc, char **argv)
{
  int opt = 0;
  int descriptor_index = 3; 
  //0 for stdin 
  //1 for stdout
  //2 for stderr
  int ifd = STDIN_FILENO;
  int ofd = STDOUT_FILENO;
  int efd;
  int o_flag = 0;
  int command_index = 0;
  int command_flag = 0;
  int command_arg_index = 0;
  int num_of_rdonly = 0;
  int index_of_rdonly[100];
  int verbose_flag = 0;

  int fd_array[100];
  int fd_array_index = 0;




  long command_index_num;

  char* opt_descriptor[100];
  char temp;
  char* command_arg[100];

  char* optarg_ptr;

  char* ans = "sleep";

  //close(1);
  //dup(0);
  //close(0);
  // printf("here\n");

  while(1)
    {
      static struct option long_options[] =
	{
	  {"rdonly", required_argument, NULL, 'r'},
	  {"wronly", required_argument, NULL, 'w'},
	  {"command", required_argument, NULL, 'c'},
	  {"verbose", no_argument, NULL, 'v'},
	  {"pipe", no_argument, NULL, 'p'},
	  {0,0,0,0}
	};

      int option_index = 0;
      
      pid_t pid;
      int status;

      opt = getopt_long(argc,argv, "-rwcvp", long_options, &option_index);

      //printf("optind is %d\n",optind);

      if(command_flag == 0 && opt == -1)//no option
	break;
      else if((command_flag == 1 && opt != 1)/* || (command_flag == 1 && optarg[0] == '>')*/)
	{
	  if(verbose_flag == 1)
	    printf("\n");
	  if((pid = fork()) < 0)
	    {
	      fprintf(stderr,"Fork fail\n");
	      exit(1);
	    }
	  else if(pid == 0)
	    {
	      command_arg[command_arg_index] = '\0';
	      close(0);
	      dup(ifd);
	      close(ifd);
	      close(1);
	      dup(ofd);
	      close(ofd);
	      close(2);
	      dup(efd);
	      close(efd);
	      if(execvp(*command_arg,command_arg) == -1)
		{
		  int temperr = errno;
		  fprintf(stderr,"exevp() fail in here\n");
		  exit(1);
		}
	    }
	  else
	    {
	      while(wait(&status) != pid);
	    }
	  command_arg_index = 0;
	  command_index = 0;
	  command_flag =0;
	}
      
      switch(opt)
	{
	case 'r':
	  if(verbose_flag == 1)
	    printf("--rdonly %s\n", optarg);
	  ifd = open(optarg,o_flag | O_RDONLY);
	  if(ifd >= 0 && ifd != descriptor_index)//not the same file descriptor
	    {
	      fd_array[fd_array_index] = ifd;
	      fd_array_index++;
	    }
	  else if(ifd >= 0 && ifd == descriptor_index)
	    {
	      fd_array[fd_array_index] = ifd;
	      fd_array_index++;
	    }
	  else if(ifd < 0)//error
	    {
	      fprintf(stderr,"file does not exist\n");
	      exit(1);
	    }
	  descriptor_index++;
	  break;
	case 'w':
	  if(verbose_flag == 1)
            printf("--rwonly %s\n", optarg);
	  ofd = open(optarg,o_flag | O_WRONLY);
          if(ofd >= 0 && ofd != descriptor_index)
            {
	      fd_array[fd_array_index] = ofd;
	      fd_array_index++;
            }
          else if(ofd < 0)
            {
              fprintf(stderr,"Cannot create file\n");
              exit(1);
            }
	  descriptor_index++;
	  break;
	case 'p':
	  
	  break;
	case 'c':
	  if(verbose_flag == 1)
	  {
	    printf("--command %s ",optarg);
	  }
	  command_flag = 1;
	  command_index_num = strtol(optarg, &optarg_ptr, 10) + 3;
	  if(strlen(optarg_ptr) != 0)//it is not a file descriptor, report error
            {
              printf("string length is %d \n",strlen(optarg_ptr));
              printf("string part is %s \n",optarg_ptr);
              printf("%c %d\n", optarg_ptr[0],optarg_ptr[0]);
            }
          else
	    {// change to the corresponding file descriptor
	      ifd = command_index_num;
	      if (fcntl(ifd, F_GETFL) < 0 && errno == EBADF) {
		fprintf(stderr,"invalid file descriptor\n");
		exit(1);
	      }
	      command_index++;
	    }
	  break;
	case 'v':
	  verbose_flag = 1;
	  break;
	case 1:
	  if(verbose_flag == 1 && optarg != NULL)
	  {
	    printf("%s ",optarg);
	  }
	  command_index_num = strtol(optarg, &optarg_ptr, 10) + 3;

	  if(strlen(optarg_ptr) != 0)
	    {//a string may be invalid options or command depends on the command flag
	      if(command_flag == 1 && command_index == 3
		 && strlen(optarg) == strlen(optarg_ptr))
		{//command with full descriptors and no numbers ahead
		  command_arg[command_arg_index] = optarg_ptr;
		  command_arg_index++;
		}
	      else if(command_flag == 1 && command_index == 3
		      &&strlen(optarg) != strlen(optarg_ptr))
		{//command with full descriptors with numbers ahead
		  command_arg[command_arg_index] = optarg;
		  command_arg_index++;
		}
	      else
		{
		  fprintf(stderr, "invalid option\n");
		  exit(1);
		}
	    }
	  else
	    {
	      if(command_flag == 0 )
		{//an integer without setting the command flag does not has meaning
		  fprintf(stderr," descriptor without a command is nothing \n");
		  exit(1);
		}
	      else if(command_flag == 1 && command_index>= 3)
		{
		  fprintf(stderr, "too many file descriptors for command \n");
		  exit(1);
		}
	      else
		{
		  if (fcntl(command_index_num, F_GETFL) < 0 && errno == EBADF) {
		    fprintf(stderr,"invalid file descriptor\n");
		    exit(1);
		  }
		  if(command_index == 1)
		    ofd = command_index_num;
		  else
		    efd = command_index_num;
		  command_index++;
		}
	    }
	  break;
	case '?':
	  //printf("In switch ? optarg is %s \n", optarg);
	  break;
	default:
	  //printf("In switch default optarg is %s \n", optarg);
	  break;
	}
    }

  
  if(ofd == STDOUT_FILENO)
    {
      int i;
      for(i = 0;i <num_of_rdonly;i++)
	{
	  while(read(index_of_rdonly[i],&temp,sizeof(char)))
	    {
	      write(STDOUT_FILENO,&temp,sizeof(char));
	    }
	}
    }
  
  return 0;
}
