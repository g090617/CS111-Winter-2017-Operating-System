#define DEFAULT_DIFF_PROGRAM "diff"
#define LOCALEDIR "/usr/local/share/locale"
